import { React } from "uebersicht";

export const command = `
user=$(whoami)
host=$(scutil --get ComputerName 2>/dev/null || hostname -s)
osver=$(sw_vers -productVersion)
osname=$(sw_vers -productName)
model=$(sysctl -n hw.model 2>/dev/null)
kernel=$(uname -r)
up=$(uptime | sed -E 's/.*up ([^,]*,[^,]*),.*/\\1/' | sed -E 's/^ +//')
shellname=$(basename "$SHELL")
term="\${TERM_PROGRAM:-unknown}"
cpu=$(sysctl -n machdep.cpu.brand_string 2>/dev/null)
res=$(system_profiler SPDisplaysDataType 2>/dev/null | awk -F': ' '/Resolution/ {print $2; exit}')

pagesize=$(vm_stat | head -1 | grep -o '[0-9]*')
active=$(vm_stat | awk '/Pages active/ {gsub("\\\\.","",$3); print $3}')
wired=$(vm_stat | awk '/Pages wired/ {gsub("\\\\.","",$4); print $4}')
compressed=$(vm_stat | awk '/occupied by compressor/ {gsub("\\\\.","",$5); print $5}')
totalbytes=$(sysctl -n hw.memsize)
usedbytes=$(( (active + wired + compressed) * pagesize ))
mem=$(awk -v u="$usedbytes" -v t="$totalbytes" 'BEGIN{printf "%.2f GiB / %.2f GiB (%.0f%%)", u/1073741824, t/1073741824, (u/t)*100}')

pkgs=$(command -v brew >/dev/null 2>&1 && echo "$(brew list --formula 2>/dev/null | wc -l | tr -d ' ') (brew)" || echo "0")

printf '%s\\n' \\
  "user::$user" \\
  "host::$host" \\
  "os::$osname $osver" \\
  "model::$model" \\
  "kernel::$kernel" \\
  "uptime::$up" \\
  "shell::$shellname" \\
  "term::$term" \\
  "cpu::$cpu" \\
  "res::$res" \\
  "mem::$mem" \\
  "pkgs::$pkgs"
`;

export const refreshFrequency = 60000;

export const className = `
  left: 300px;
  top: 30px;
  font-family: "Menlo", "SF Mono", monospace;
  font-size: 12px;
  line-height: 1.5;
  color: #d8dee9;
  background: rgba(20, 20, 24, 0.55);
  backdrop-filter: blur(14px);
  -webkit-backdrop-filter: blur(14px);
  padding: 22px 28px;
  border-radius: 12px;
  box-shadow: 0 8px 30px rgba(0,0,0,0.35);

  .row {
    display: flex;
  }

  .logo {
    white-space: pre;
    font-weight: normal;
    font-size: 13px;
    line-height: 1.28;
    letter-spacing: 0.5px;
    margin-right: 34px;
  }
  .logo .l1 { color: #a3be8c; }
  .logo .l2 { color: #ebcb8b; }
  .logo .l3 { color: #d08770; }
  .logo .l4 { color: #bf616a; }
  .logo .l5 { color: #b48ead; }
  .logo .l6 { color: #81a1c1; }
  .logo .l7 { color: #8fbcbb; }
  .logo .l8 { color: #e5e9f0; }

  .info {
    white-space: pre;
  }

  .title {
    color: #eceff4;
    font-weight: bold;
  }

  .rule {
    color: #4c566a;
  }

  .key {
    color: #ebcb8b;
    font-weight: bold;
  }

  .val {
    color: #e5e9f0;
  }

  .swatches {
    display: flex;
    margin-top: 12px;
  }
  .swatches div {
    width: 22px;
    height: 16px;
  }
`;

const APPLE_LOGO = [
  ["l1", "                    'c."],
  ["l2", "                 ,xNMM."],
  ["l2", "               .OMMMMo"],
  ["l2", "               OMMM0,"],
  ["l3", "     .;loddo:' loolloddol;."],
  ["l3", "   cKMMMMMMMMMMNWMMMMMMMMMM0:"],
  ["l4", " .KMMMMMMMMMMMMMMMMMMMMMMMWd."],
  ["l4", " XMMMMMMMMMMMMMMMMMMMMMMMX."],
  ["l4", ";MMMMMMMMMMMMMMMMMMMMMMMM:"],
  ["l5", ":MMMMMMMMMMMMMMMMMMMMMMMM:"],
  ["l5", ".MMMMMMMMMMMMMMMMMMMMMMMMX."],
  ["l5", " kMMMMMMMMMMMMMMMMMMMMMMMMWd."],
  ["l6", ".XMMMMMMMMMMMMMMMMMMMMMMMMMMk"],
  ["l6", "  .XMMMMMMMMMMMMMMMMMMMMMMMMK."],
  ["l7", "    kMMMMMMMMMMMMMMMMMMMMMMd"],
  ["l7", "     ;KMMMMMMMWXXWMMMMMMMk."],
  ["l8", "       .cooc,.    .,coo:."],
];

const SWATCH_COLORS = [
  "#2e3440", "#bf616a", "#a3be8c", "#ebcb8b",
  "#81a1c1", "#b48ead", "#8fbcbb", "#e5e9f0",
  "#4c566a", "#d08770", "#8fbcbb", "#eceff4",
];

const parse = (output) => {
  const map = {};
  (output || "").split("\n").forEach((line) => {
    const idx = line.indexOf("::");
    if (idx === -1) return;
    map[line.slice(0, idx)] = line.slice(idx + 2).trim();
  });
  return map;
};

const Row = ({ label, value }) => (
  <div>
    <span className="key">{label}</span>
    <span className="val">: {value}</span>
  </div>
);

export const render = ({ output, error }) => {
  const d = parse(output);
  const title = `${d.user || "user"}@${d.host || "mac"}`;

  return (
    <div className="row">
      <div className="logo">
        {APPLE_LOGO.map((l, i) => (
          <div key={i} className={l[0]}>{l[1]}</div>
        ))}
      </div>
      <div className="info">
        <div className="title">{title}</div>
        <div className="rule">{"-".repeat(title.length)}</div>
        {error ? (
          <div className="val">error running command</div>
        ) : (
          <>
            <Row label="OS" value={d.os} />
            <Row label="Host" value={d.model} />
            <Row label="Kernel" value={d.kernel} />
            <Row label="Uptime" value={d.uptime} />
            <Row label="Packages" value={d.pkgs} />
            <Row label="Shell" value={d.shell} />
            <Row label="Resolution" value={d.res} />
            <Row label="Terminal" value={d.term} />
            <Row label="CPU" value={d.cpu} />
            <Row label="Memory" value={d.mem} />
          </>
        )}
        <div className="swatches">
          {SWATCH_COLORS.map((c, i) => (
            <div key={i} style={{ background: c }} />
          ))}
        </div>
      </div>
    </div>
  );
};
